TO RUN THE PROJECT:
1. download all files related to the project
2. open terminal window in the folder where these files are saved
3. type "make" followed by the scheduling method you chose to use
	i.e "make fcfs"
4. execute the scheduler by typing the method chosen followed by the correct txt file
	i.e "./fcfs schedule.txt"
	note: for priority scheduling it is pri-schedule.txt
	      for rr scheduling it is rr-schedule.txt
