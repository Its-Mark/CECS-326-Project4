/**
 * Non-preemptive priority scheduling algorithm.
 */
 
import java.util.*;

// Your code here