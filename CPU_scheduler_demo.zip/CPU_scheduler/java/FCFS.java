/**
 * FCFS scheduling algorithm.
 */
 
import java.util.*;

//Your code here